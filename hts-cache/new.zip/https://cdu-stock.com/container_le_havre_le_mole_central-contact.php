

<!DOCTYPE html>
<html lang="fr">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head><meta charset="utf-8" /><meta http-equiv="Content-Language" content="fr-fr" /><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta content="width=device-width, initial-scale=1, minimum-scale=1.0, shrink-to-fit=no" name="viewport" /><meta name="apple-mobile-web-app-capable" content="yes" /><meta name="robots" content="index,follow" /><meta http-equiv="x-ua-compatible" content="ie=edge" />
	<!-- favicon -->
	<!--  <link rel="shortcut icon" type="image/x-icon" href="favicon.ico" /> -->
<!-- 	<link rel="icon" href="images/favicon/favicon.ico" type="image/x-icon" /> 
 -->	<!-- <link rel="apple-touch-icon" sizes="57x57" href="images/favicon/apple-icon-57x57.png" /><link rel="apple-touch-icon" sizes="60x60" href="images/favicon/apple-icon-60x60.png" /><link rel="apple-touch-icon" sizes="72x72" href="images/favicon/apple-icon-72x72.png" /><link rel="apple-touch-icon" sizes="76x76" href="images/favicon/apple-icon-76x76.png" /><link rel="apple-touch-icon" sizes="114x114" href="images/favicon/apple-icon-114x114.png" /><link rel="apple-touch-icon" sizes="120x120" href="images/favicon/apple-icon-120x120.png" /><link rel="apple-touch-icon" sizes="144x144" href="images/favicon/apple-icon-144x144.png" /><link rel="apple-touch-icon" sizes="152x152" href="images/favicon/apple-icon-152x152.png" /><link rel="apple-touch-icon" sizes="180x180" href="images/favicon/apple-icon-180x180.png" /><link rel="icon" type="image/png" sizes="192x192" href="images/favicon/android-icon-192x192.png" /><link rel="icon" type="image/png" sizes="32x32" href="images/favicon/favicon-32x32.png" /><link rel="icon" type="image/png" sizes="96x96" href="images/favicon/favicon-96x96.png" /> -->
	<link rel="icon" type="image/png"  href="images/favicon/favicon-16x16.png" />
<!-- 	<link rel="manifest" href="images/favicon/manifest.json" /><meta name="msapplication-TileColor" content="#378AC4" />
	<meta name="msapplication-TileImage" content="images/favicon/ms-icon-144x144.png" /><meta name="theme-color" content="#378AC4" /> -->
	<!-- .favicon -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800%7CShadows+Into+Light%7CPlayfair+Display:400" rel="stylesheet" type="text/css" />
	<!-- Customize Theme css here -->
	<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css" /><link rel="stylesheet" href="vendor/animate/animate.min.css" /><link rel="stylesheet" href="vendor/simple-line-icons/css/simple-line-icons.min.css" /><link rel="stylesheet" href="vendor/owl.carousel/assets/owl.carousel.min.css" /><link rel="stylesheet" href="vendor/owl.carousel/assets/owl.theme.default.min.css" /><link rel="stylesheet" href="vendor/magnific-popup/magnific-popup.min.css" /><link rel="stylesheet" href="css/theme.css" /><link rel="stylesheet" href="css/theme-elements.css" /><link rel="stylesheet" href="css/theme-blog.css" /><link rel="stylesheet" href="css/theme-shop.css" /><link rel="stylesheet" href="vendor/rs-plugin/css/settings.css" /><link rel="stylesheet" href="vendor/rs-plugin/css/layers.css" /><link rel="stylesheet" href="vendor/rs-plugin/css/navigation.css" /><link rel="stylesheet" href="css/skins/default.css" /><link rel="stylesheet" href="css_2020/update.css" /><link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />

	<script src="vendor/modernizr/modernizr.min.js"></script>
	<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

	<!-- .Customize Theme css here -->
	<link rel="stylesheet" href="css/selfstockage.css">
		<link rel="stylesheet" href="css/custom.min.css" />
	<title>
	CDU vente location transformation de container
</title>
<!-- APPLICATION --><meta name='url' content='https://www.cdu-stock.com/' /><meta name='description' lang='fr' content='Spécialiste dans la vente de containers et bungalow sur toute la France, CDU vous propose également la location et transformation de conteneurs maritimes à destination des particuliers et professionnels.' /><meta name='keywords' lang='fr' content='container, conteneur, bungalow, box' /><meta name='Subject' content='Location containers' /><meta name='Identifier-Url' content='https://www.cdu-stock.com/' /><meta name='author' content='contact@cdu-stock.com' /><meta http-equiv='content-language' content='fr-FR' /><meta name='language' content='fr-FR' /><meta name='category' content='general' /><meta name='distribution' content='global' /><meta name='resource-type' content='document' /><meta name='copyright' content='Graphibox' /><meta name='application-name' content='CDU' />
<!-- GEO LOCALISATION --><meta name='geo.region' content='FR-32' /><meta name='geo.placename' content='Seysses' /><meta name='geo.position' content='1.320017;43.490294' /><meta name='ICBM' content='1.320017, 43.490294' />
<!-- DUBLIN CORE --><meta name='dc.language' CONTENT='fr-FR' /><meta name='dc.source' CONTENT='https://www.cdu-stock.com/' /><meta name='dc.relation' CONTENT='https://www.cdu-stock.com/' /><meta name='dc.title' CONTENT="CDU" /><meta name='dc.description' CONTENT='Vente de containers maritimes, location de conteneurs / self stockage, CDU dispose de nombreux dépôts logistiques pour une livraison partout en France. Nos bureaux sont situés à Pujaudran dans le Gers, près de Toulouse et à  Seysses, haute-Garonne.' /><meta name='dc.keywords' CONTENT='containers, maritime, conteneur, stockage, CDU' /><meta name='dc.subject' CONTENT='Location containers' />
<!-- SOCIAL NETWORKS --><meta name='DC.Description' content='Spécialiste dans la vente de containers et bungalow sur toute la France, CDU vous propose également la location et transformation de conteneurs maritimes à destination des particuliers et professionnels.' /><meta name='DC.Keywords' content='container, conteneur, bungalow, box' />
<meta name='DC.Subject' content='CDU vente location transformation de container' /><meta name='DC.Identifier-Url' content='https://www.cdu-stock.com/' />

<!-- Facebook Meta Tags -->
<meta property="og:url" content="https://cdu-stock.com">
<meta property="og:type" content="website">
<meta property="og:title" content="CDU vente location transformation de container">
<meta property="og:description" content="Spécialiste dans la vente de containers et bungalow sur toute la France, CDU vous propose également la location et transformation de conteneurs maritimes à destination des particuliers et professionnels.">
<meta property="og:image" content="https://www.cdu-stock.com/images/sociaux/logoSocial.png">

<meta name='twitter:title' content='CDU vente location transformation de container' />
<meta name='twitter:description' content='Spécialiste dans la vente de containers et bungalow sur toute la France, CDU vous propose également la location et transformation de conteneurs maritimes à destination des particuliers et professionnels.' />
<meta name='twitter:image' content='https://www.cdu-stock.com/images/sociaux/logoSocial.png' />

	<meta http-equiv="Cache-control" content="public">
	 <link rel="stylesheet" href="css/map-pins.css">
<link rel="stylesheet" href="https://cdn-gbbu02.graphibox.eu/builds/fonts/fontawesome-v5.12.0/fonts-fontawesome.all.min.css" />
<style type="text/css">
	


	
                          #google_translate_element2 {display:none!important;}
  .goog-te-banner-frame{
            display: none!important;
        }
        body{
            position: static!important;
            min-height: initial!important;
        }
.goog-tooltip{ display:  none!important;}
.goog-text-highlight {
  box-shadow: none !important;
  background-color: transparent !important;
</style>

</head>

<body class="loading-overlay-showing" data-plugin-page-transition data-loading-overlay
	data-plugin-options="{'hideDelay': 500}">

		<div id="cookiebar" class="backColor1">
			<div class="Row">En poursuivant votre navigation sur le site, vous acceptez l'utilisation des cookies sur
				l’ensemble des pages de notre site internet. <a href="javascript:AcceptCookies();"
					class="btn-cookie-bar">OK</a> <a href="mentions.php">En savoir +</a></div>
		</div>
		<div class="loading-overlay">
			<div class="bounce-loader">
				<div class="bounce1"></div>
				<div class="bounce2"></div>
				<div class="bounce3"></div>
			</div>
		</div>
		<div class="body">
			<header id="header" class="header-effect-shrink"
				data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyChangeLogo': true, 'stickyStartAt': 120, 'stickyHeaderContainerHeight': 70}">
				<div class="header-body border-color-primary header-body-bottom-border">
					<div class="header-top header-top-default border-bottom-0">
						<div class="container">
							<div class="header-row py-2">
								<div class="header-column justify-content-start">
									<div class="header-row">
										<nav class="header-nav-top">
											<ul class="nav nav-pills">
												<li class="nav-item nav-item-anim-icon d-md-block">
													
													
														<h1 class="h-slogan"><b>CDU</b> / Société spécialisée dans
															le self-stockage, container maritime et bâtiment modulaire
														</h1>
													
													
												</li>
											</ul>
										</nav>
									</div>
								</div>
								<div class="header-column justify-content-end">
									<div class="header-row">
										<nav class="header-nav-top">
											<ul class="nav nav-pills">
												<li class="nav-item">
													<a id="HplTelHeader1" href="tel:+ 1 613-7067-013"><i class='fas fa-phone text-3 textColor1'></i> + 1 613-7067-013</a>
												</li>
												<li class="nav-item">
													<ul class="header-social-icons social-icons d-sm-block">
		<li> <a href="javascript:void()"  onclick="window.location.hash='#googtrans(en)';location.reload();"><img src="img/en.png" align="center"> </a></li>
                                        <li><a href="javascript:void()"  onclick="window.location.hash='#googtrans(de)';location.reload();"><img src="img/de.png" align="center"> </a></li>
                                   
                                          
 <li><a href="javascript:void()"  onclick="window.location.hash='#googtrans(es)';location.reload();"><img src="img/es.png" align="center">  </a> </li>
  <li><a href="javascript:void()"  onclick="window.location.hash='#googtrans(fr)';location.reload();"><img src="img/fr.png" align="center">  </a> </li>
  <li><a href="javascript:void()"  onclick="window.location.hash='#googtrans(it)';location.reload();"><img src="img/it.png" align="center">  </a> </li>
   <li><a href="javascript:void()"  onclick="window.location.hash='#googtrans(en)';location.reload();"><img src="img/ca.png" align="center">  </a> </li>
													</ul>
												</li>
											</ul>
										</nav>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="header-container container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									<div class="header-logo">
										<a id="HplHomeHeader" href="index.php"><img id="ImgLogo1Header" title="Stockobox" src="images/Logos/Logo1.png" alt="Stockobox" /></a>
									</div>
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									<div class="header-nav header-nav-links order-2 order-lg-1">
										<div
											class="header-nav-main header-nav-main-square header-nav-main-effect-2 header-nav-main-sub-effect-1">
											<nav class="collapse">
												<ul class="nav nav-pills" id="mainNav">
                                                    <!-- <li class="dropdown">
														<a id="HplMenuHome" title="Accueil" class="dropdown-item dropdown-toggle active" href="https://www.cdu-stock.com/">Accueil</a>
													</li>-->
													<li class="dropdown">
														<a id="HplMenuVenteTitre" title="Vente" class="dropdown-item dropdown-toggle" href="vente-conteneur-acheter.php">Vente</a>
													</li>
                                                    <li class="dropdown">
														<a id="HplMenuNosContainers" title="Nos containers" class="dropdown-item dropdown-toggle" href="containeurs-vente.php">Nos containers</a>
													</li>
                                                    <li class="dropdown">
														<a id="HplMenuNosBungalows" title="Nos bungalows" class="dropdown-item dropdown-toggle" href="bungalows.php">Nos bungalows</a>
													</li>
													<li class="dropdown">
														<a id="HplMenuTransformationTitre" title="Transformation &amp; aménagement" class="dropdown-item dropdown-toggle" href="transformation-amenagement-container.php"><span class='mn-long'>Transformation & </span> Aménagement</a>
													</li>
													<li class="dropdown">
														<a id="HplMenuContainerTitre" title="Box mobile" class="dropdown-item dropdown-toggle" href="box-mobile.php"><span class='mn-long'>Box</span> mobile</a>
													</li>
													<!-- <li class="dropdown"><a id="HplMenuContenersTitre" title="Containers mobiles" class="dropdown-item dropdown-toggle" href="https://www.cdu-stock.com/">Containers mobiles</a></li> -->
													<li class="dropdown">
														<a id="HplMenuStockageTitre" title="Self Stockage" class="dropdown-item dropdown-toggle" href="location-conteneur-self-stockage.php">Self Stockage</a>
													</li>
													<li class="dropdown">
														<a id="HplMenuContactTitre" title="Contact" class="dropdown-item dropdown-toggle" href="contact.php">Contact</a>
													</li>
												</ul>
											</nav>
										</div><a href="javascript:;" class="btn header-btn-collapse-nav"
											data-toggle="collapse" data-target=".header-nav-main nav"><i
												class="fas fa-bars"></i></a>
									</div>
								</div>
							</div>
						</div>

					</div>
				</div>
			</header>			<div role="main" class="main">
				


	<section class="page-header page-header-classic">
		<div class="container">
			<div class="row">
				<div class="col">
					<ul class="breadcrumb">
						<li>
							<a id="pContent_HplArianeHome" title="Accueil" href="index.php">Accueil</a>
						</li>
						<li class="active">
							Acheter un conteneur à Le Havre Le Môle Central
						</li>
					</ul>
				</div>
			</div>
			<div class="row">
				<div class="col p-static"><span class="page-header-title-border visible"
						style="width: 149.547px;"></span>
					<h1 data-title-border="">Contactez-nous</h1>
				</div>
			</div>
		</div>
	</section>

	<!-- Google Maps - Go to the bottom of the page to change settings and map location. -->
	<section id="pContent_SectionMapIFrame" class="map-g">
		<iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d82924.88553474005!2d0.061144881801869985!3d49.495789358537294!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e02f2395218b7d%3A0x5bc1867aaf33af12!2sLe%20Havre!5e0!3m2!1sfr!2sfr!4v1575542578526!5m2!1sfr!2sfr' width='100%' height='450' frameborder='0' style='border:0;' allowfullscreen=''></iframe>
	</section>

	

	<div id="pContent_PnlForm" class="container">
	
		<div class="row py-4">
			<div id="pContent_PnlFormLeft" class="col-lg-6">
		

				<div class="overflow-hidden mb-1">
					<h2 class="font-weight-normal text-7 mt-2 mb-0 appear-animation" data-appear-animation="maskUp"
						data-appear-animation-delay="200"><strong class="font-weight-extra-bold">Contactez</strong>-nous
					</h2>
				</div>
				<div class="overflow-hidden mb-4 pb-3">
					<p class="mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="400">
						N'hésitez pas à nous contacter, nous serons ravis de vous conseiller sur votre futur projet.</p>
				</div>
<form method="post" action="" id="form1">
				<div id="contactForm" class="contact-form">


					


					<div class="form-row">
						<div class="form-group col-lg-6">
							<label class="required font-weight-bold text-dark text-2">Nom</label>
							<input name="snom" type="text" maxlength="100" id="pContent_txtNom" class="form-control" data-msg-required="Entrez votre nom." required="" />
						</div>
						<div class="form-group col-lg-6">
							<label class="required font-weight-bold text-dark text-2">Prénom</label>
							<input name="sprenom" type="text" maxlength="100" id="pContent_txtPrenom" class="form-control" data-msg-required="Entrez votre prénom." required="" />
						</div>
					</div>
					<div class="form-row">
						<div class="form-group col-lg-6">
							<label class="font-weight-bold text-dark text-2">Société</label>
							<input name="ssociete" type="text" maxlength="100" id="pContent_txtSociete" class="form-control" />
						</div>
					</div>

					<div class="form-row">
						<div class="form-group col-lg-6">
							<label class="required font-weight-bold text-dark text-2">Adresse email</label>
							<input name="semail" type="email" maxlength="100" id="pContent_txtEmail" class="form-control" data-msg-required="Entrez votre adresse email." required="" />
						</div>
						<div class="form-group col-lg-6">
							<label class="required font-weight-bold text-dark text-2">Téléphone</label>
							<input name="sphone" type="text" maxlength="100" id="pContent_txtTel" class="form-control" data-msg-required="Entrez votre numéro de téléphone." required="" />
						</div>
					</div>

					<div class="form-row">
						<div class="form-group col-lg-6">
							<label class="required font-weight-bold text-dark text-2">Code postal</label>
							<input name="scodpost" type="number" maxlength="10" id="pContent_txtCP" class="form-control" data-msg-required="Entrez votre code postal." required="" />
						</div>
						<div class="form-group col-lg-6">
							<label class="required font-weight-bold text-dark text-2">Ville</label>
							<input name="sville" type="text" maxlength="100" id="pContent_txtVille" class="form-control" data-msg-required="Entrez votre ville." required="" />
						</div>
					</div>

					<div class="form-row">
						<div class="form-group col">
							<label class="font-weight-bold text-dark text-2">Je souhaite...</label><br />
							<select name="ssouhaits" id="pContent_rcbSouhaits" class="form-drpLst">
			<option selected="selected" value="0">--- Choisir ici ---</option>
			<option value="1">Acheter un container ou un bungalow</option>
			<option value="2">Am&#233;nager/transformer un container</option>
			<option value="3">Louer un box &#224; SEYSSES (FRANCE - 31)</option>
			<option value="4">Louer un box &#224; PUJAUDRAN (FRANCE - 32)</option>
			<option value="5">Box mobile</option>
			<option value="6">Autre demande...</option>

		</select>
						</div>
					</div>

					<div class="form-row">
						<div class="form-group col">
							<label class="required font-weight-bold text-dark text-2">Message</label>
							<textarea name="smessage" rows="8" cols="20" id="pContent_txtMessage" class="form-control" data-msg-required="Veuillez écrire un message à nous envoyer." required="">
</textarea>
						</div>
					</div>
					<div class="form-row">
						<div class="form-group col">
							<input type="submit" name="menvoyer" value="Envoyer" id="pContent_BtnEnvoyer" class="btn btn-primary btn-modern" data-loading-text="Envoi..." />
						</div>
					</div>

					

				</div>

			</form>	
	</div>
			<div id="pContent_PnlDescribeRight" class="col-lg-6 box-describe">
		
				<h4 class="pt-5"><strong>CDU</strong></h4>
				<p class="mb-0 text-4">
					<strong>Vous recherchez un <em>conteneur</em> neuf ou d'occasion à <em>LE HAVRE LE MÔLE CENTRAL et ses alentours ?</em></strong><br><br><strong>CDU</strong> dispose de nombreux dépôts logistiques permettant une livraison partout en France et en Europe.<br><br>Si vous avez des questions, notre équipe se tient à votre disposition pour tout renseignement.
					<p style='padding: 30px 0 20px 0;font-size: 2em;color: #378ac4;font-weight: 600;'>+ 1 613-7067-013</p>
				</p>
			
	</div>
		</div>
	
</div>
	

			</div>
			
<footer id="footer">
				<div class="container">
					<div class="footer-ribbon"><span>
							<a id="HplFooterQuestion" href="contact.php">Une question ?</a>
						</span></div>
					<div class="row ln-1">
						<div class="col-md-6 col-lg-9 mb-4 mb-lg-0">
							<h5 class="text-3 mb-3">PRESENTATION</h5>
							<p class="pr-1">
								CDU est une société créée en 2015, spécialisée dans le self-stockage et la
								transformation de containers maritimes à WORMHOUT.
								Pour faire face à une forte demande, un deuxième établissement a vu le jour dans le Gers
								en 2018.
								Notre équipe est à votre écoute pour tous vos besoins de stockage, transformation et
								vente de containers maritimes.
							</p>
						</div>
						<div class="col-md-6 col-lg-3 mb-4 mb-md-0">
							<div class="contact-details">
								<!--<h5 class="text-3 mb-3">Contact</h5>-->
								<div class="footer-phone noview">
									<a href='tel:+ 1 613-7067-013'><i class='fab fa-whatsapp textColor1'></i>&nbsp; + 1 613-7067-013</a>
								</div>
								<ul class="list list-icons list-icons-lg">
									<li class="mb-1 noview"><i class="fab fa-whatsapp text-color-primary"></i>
										<p class="m-0">
											<a id="LtlFooterPhone2" href="javascript:;"><a href='tel:+ 1 613-7067-013'>+ 1 613-7067-013</a></a>
										</p>
									</li>
									<li class="mb-1 noview"><i class="far fa-dot-circle text-color-primary"></i>
										<p class="m-0">
											<a id="HplFooterAddress" href="javascript:;">8 rue Danielle Casanova 31600 Seysses</a>
										</p>
									</li>
									<li class="mb-1 noview"><i class="far fa-envelope text-color-primary"></i>
										<p class="m-0">
											<a id="HplFooterMail1" href="mailto:seysses@cdu-stock.com">seysses@cdu-stock.com</a>
										</p>
									</li>
									<li class="mb-1 noview"><i class="far fa-envelope text-color-primary"></i>
										<p class="m-0">
											<a id="HplFooterMail2" href="mailto:pujaudran@cdu-stock.com">pujaudran@cdu-stock.com</a>
										</p>
									</li>
								</ul>
							</div>
							<h5 class="text-3 mb-3">Suivez-nous</h5>
							<ul class="social-icons">
								<li class="social-icons-facebook"><a href="https://www.facebook.com/stockobox"
										target="_blank" title="Suivez Stockobox sur Facebook"><i
											class="fab fa-facebook-f"></i></a></li>
								<li class="social-icons-twitter"><a href="https://twitter.com/stockobox" target="_blank"
										title="Suivez Stockobox sur Twitter"><i class="fab fa-twitter"></i></a></li>
								<li class="social-icons-instagram"><a href="https://www.instagram.com/stockobox/"
										target="_blank" title="Suivez Stockobox sur Instagram"><i
											class="fab fa-instagram"></i></a></li>
								<li class="social-icons-linkedin"><a href="https://www.linkedin.com/company/stockobox"
										target="_blank" title="Suivez Stockobox sur Linkedin"><i
											class="fab fa-linkedin-in"></i></a></li>
							</ul>
						</div>
					</div>
					<div class="row ln-2">
						<div class="col-md-12 col-lg-12 mb-12 mb-lg-0">
							<div class="col-footer-inside">
								<h5 class="text-3 mb-3">Aide et contact</h5>
								<ul class="list list-icons list-icons-lg">
									<li class="mb-1"><i class="fas fa-angle-right text-color-primary"></i>
										<p class="m-0"><a href="transformation-amenagement-container.php"
												title="Transformations & aménagement de containers">Transformations<br>&
												aménagement<br>de containers</a></p>
									</li>
									<li class="mb-1"><i class="fas fa-angle-right text-color-primary"></i>
										<p class="m-0"><a href="vente-conteneur-acheter.php"
												title="Vente Containers">Vente Containers</a></p>
									</li>
									<li class="mb-1"><i class="fas fa-angle-right text-color-primary"></i>
										<p class="m-0"><a href="location-conteneur-self-stockage.php"
												title="Location Conteneurs">Location Containers</a></p>
									</li>
									<li class="mb-1"><i class="fas fa-angle-right text-color-primary"></i>
										<p class="m-0"><a href="container-stockage-blog-actualites.php"
												title="Blog & Actualités stockage & containers">Blog</a></p>
									</li>
									<li class="mb-1">
										<i class="fas fa-angle-right text-color-primary"></i>
										<p class="m-0">
										<a href="box-mobile.php" title="Containeurs mobiles">
											Containeurs mobiles
											</a>
										</p>
									</li>

									<li class="mb-1"><i class="fas fa-angle-right text-color-primary"></i>
										<p class="m-0"><a href="mentions.php"
												title="Mentions légales">Mentions légales</a></p>
									</li>
									<li class="mb-1"><i class="fas fa-angle-right text-color-primary"></i>
										<p class="m-0"><a href="plan-du-site.php"
												title="Plan du site">Plan du site</a></p>
									</li>
									<li class="mb-1"><i class="fas fa-angle-right text-color-primary"></i>
										<p class="m-0"><a href="contact.php"
												title="Contact">Contact</a></p>
									</li>
								</ul>
							</div>
							<div id="PnlProduits" class="col-footer-inside">
	
								<h5 class="text-3 mb-3">Containers de stockage</h5>
								<ul class="list list-icons list-icons-lg">
									<li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='container_40_pieds_high_cube-containers-24-7.php' title="Container 40 PIEDS HIGH CUBE">Container 40 PIEDS HIGH CUBE</a></p></li><li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='container_8_pieds-containers-25-7.php' title="Container 8 pieds">Container 8 pieds</a></p></li><li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='container_10_pieds-containers-26-7.php' title="Container 10 pieds">Container 10 pieds</a></p></li><li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='container_20_pieds-containers-27-7.php' title="Container 20 pieds">Container 20 pieds</a></p></li><li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='container_40_pieds-containers-28-7.php' title="Container 40 pieds">Container 40 pieds</a></p></li><li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='container_frigorifique-containers-29-7.php' title="Container frigorifique">Container frigorifique</a></p></li><li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='container_chantier-containers-30-7.php' title="Container chantier">Container chantier</a></p></li><li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='container_premier_voyage-containers-34-7.php' title="Container premier voyage">Container premier voyage</a></p></li><li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='container_occasions-containers-32-7.php' title="Container occasions">Container occasions</a></p></li><li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='container_neuf-containers-33-7.php' title="Container neuf">Container neuf</a></p></li>
								</ul>
							
</div>
							<div id="PnlRealisations" class="col-footer-inside">
	
								<h5 class="text-3 mb-3">Réalisations</h5>
								<ul class="list list-icons list-icons-lg">
									<li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='container_40_avec_rideaux_metalliques_pour_du_self_stockage-containers-22-6.php' title="Container 40' avec rideaux métalliques pour du Self-Stockage">Container 40' avec rideaux métalliques pour du Self-Stockage</a></p></li><li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='container_totem_40_a_la_verticale-containers-20-6.php' title="Container totem 40' à la verticale">Container totem 40' à la verticale</a></p></li><li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='escalier_en_container-containers-19-6.php' title="Escalier en container">Escalier en container</a></p></li><li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='container_transforme_avec_des_portes_pour_du_self_stockage-containers-21-6.php' title="Container transformé avec des portes pour du Self-Stockage">Container transformé avec des portes pour du Self-Stockage</a></p></li>
								</ul>
							
</div>
							<div id="PnlVilles" class="col-footer-inside">
	
								<h5 class="text-3 mb-3">Sites</h5>
								<ul class="list list-icons list-icons-lg">
									<li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='contact.php' title="Acheter, louer un conteneur à Seattle">Acheter, louer un conteneur à Seattle</a></p></li>

									<li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='contact.php' title="Acheter, louer un conteneur à Portland">Acheter, louer un conteneur à Portland</a></p></li>

									<li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='contact.php' title="Acheter un conteneur à San Francisco">Acheter un conteneur à San Francisco</a></p></li>

									<li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='contact.php' title="Acheter un conteneur à Los Angeles">Acheter un conteneur à Los Angeles</a></p></li>

									<li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='contact.php' title="Acheter un conteneur à Dunkerque, proche de  	Atlanta">Acheter un conteneur à Dunkerque, proche de  	Atlanta</a></p></li>

									<li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='contact.php' title="Acheter un conteneur à  Miami">Acheter un conteneur à  	Miami</a></p></li>

									<li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='contact.php' title="Acheter un conteneur à  	Baltimore">Acheter un conteneur à Baltimore</a></p></li><li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='contact.php' title="Acheter un conteneur à  	Boston">Acheter un conteneur à  	Boston</a></p></li><li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='contact.php' title="Acheter un conteneur à  	Montreal">Acheter un conteneur à  	Montreal</a></p></li><li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='contact.php' title="Acheter un conteneur à  	Toronto">Acheter un conteneur à  	Toronto</a></p></li><li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='contact.php' title="Acheter un conteneur à  	Vancouver">Acheter un conteneur à  	Vancouver</a></p></li>
									<li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='contact.php' title="Acheter un conteneur à  	Edmonton">Acheter un conteneur à  	Edmonton</a></p></li>
									<li class='mb-1'><i class='fas fa-angle-right text-color-primary'></i><p class='m-0'><a href='contact.php' title="Acheter un conteneur à  	Winnipeg">Acheter un conteneur à Rouen</a></p></li>
								</ul>
							
</div>
						</div>
					</div>
				</div>
				<div class="footer-copyright">
					<div class="container py-2">
						<div class="row py-4">
							<div
								class="col-lg-2 d-flex align-items-center justify-content-center justify-content-lg-start mb-2 mb-lg-0">
								<a id="HplHomeFooter" href="index.php"><img id="ImgLogo2Footer" title="Stockobox" src="images/Logos/Logo2.png" alt="Stockobox" style="height:33px;" /></a>
							</div>
							<div
								class="col-lg-6 d-flex align-items-center justify-content-center justify-content-lg-start mb-4 mb-lg-0">
								<p>&copy; Copyright 2020. Tous droits réservés.
									<a href='https://www.graphibox.biz/' Target='_blank' title='Graphibox - Agence digitale & hébergement'>&copy; Graphibox</a>
								</p>
							</div>
							<div
								class="col-lg-4 d-flex align-items-center justify-content-center justify-content-lg-end">
								<nav id="sub-menu">
									<ul>
										<li>
											<i class="fas fa-angle-right"></i>
											<a href="plan-du-site.php" 
											class="ml-1 text-decoration-none" title=" Plan du site"> 
											Plan du site
										</a>
										</li>
										<li><i class="fas fa-angle-right"></i><a
												href="mentions.php"
												class="ml-1 text-decoration-none" title="Mentions légales"> Mentions
												légales</a></li>
										<li><i class="fas fa-angle-right"></i><a href="contact.php"
												class="ml-1 text-decoration-none" title="Contact"> Contact</a></li>
									</ul>
								</nav>
							</div>
						</div>
					</div>
				</div>
			</footer>
		</div>

		<!-- schema.org -->
		<div id="hcard-Stockobox" class="vcard noview">
			<img style="width:1px;height:1px" src="images/Logos/logoSocial.png" alt="photo of "
				class="photo" /><br /><a class="url fn" href="index.php">CDU SAS</a>
			<div class="org">CDU SAS</div><a class="email"
				href="mailto:seysses@cdu-stock.com">seysses@cdu-stock.com</a>
			<div class="adr">
				<div class="street-address">8 rue Danielle Casanova</div><span
					class="locality">Seysses</span>, <span
					class="postal-code">31600</span>, <span
					class="country-name">France</span>
			</div>
			<div class="tel">Seysses</div>
		</div>
		<!-- .schema.org -->

		<!-- Vendor -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/jquery.appear/jquery.appear.min.js" defer></script>
		<script src="vendor/jquery.easing/jquery.easing.min.js" defer></script>
		<script src="vendor/jquery.cookie/jquery.cookie.min.js" defer></script>
		<script src="vendor/popper/umd/popper.min.js" defer></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js" defer></script>
		<script src="vendor/common/common.min.js" defer></script>
		<script src="vendor/jquery.validation/jquery.validate.min.js" defer></script>
		<script src="vendor/jquery.easy-pie-chart/jquery.easypiechart.min.js" defer></script>
		<script src="vendor/jquery.gmap/jquery.gmap.min.js" defer></script>
		<script src="vendor/jquery.lazyload/jquery.lazyload.min.js" defer></script>
		<script src="vendor/isotope/jquery.isotope.min.js" defer></script>
		<script src="vendor/owl.carousel/owl.carousel.min.js" defer></script>
		<script src="vendor/magnific-popup/jquery.magnific-popup.min.js" defer></script>
		<script src="vendor/vide/jquery.vide.min.js" defer></script>
		<script src="vendor/vivus/vivus.min.js" defer></script>
		<script src="js/theme.js" defer></script>
		<!--<script src="vendor/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
		<script src="vendor/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>-->
		<script src="js/theme.init.js" defer></script>


		<!-- // Personnal Footer // -->
		
		
<!-- schema.org --><div class='noview' itemscope itemtype='http://schema.org/Organization'> <span itemprop='name'>CDU</span> <span itemprop='address'>8 rue Danielle Casanova 31600 Seysses</span> <span itemprop='telephone'>+ 1 613-7067-013</span></div><div class='noview' itemscope itemprop='PostalAddress' itemtype='http://schema.org/PostalAddress'> <span itemprop='streetAddress'>8 rue Danielle Casanova</span>  <span itemprop='postalCode'>31600</span> <span itemprop='addressLocality'>Seysses</span> <span itemprop='addressRegion'>Gers</span> <span itemprop='addressCountry'>France</span></div><!-- .schema.org -->

		
		
			<script src="js/custom.min.js"></script>
		
		
		
		
	</form>
	<!-- add analytics here -->

	
		<!-- Global site tag (gtag.js) - Google Analytics -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=UA-154708020-1"></script>
		<script>
			window.dataLayer = window.dataLayer || [];
			function gtag() { dataLayer.push(arguments); }
			gtag('js', new Date());

			gtag('config', 'UA-154708020-1');

			//AOS = Animate On Scrool
				AOS.init({
				// Global settings:
				//disable: false, // accepts following values: 'phone', 'tablet', 'mobile', boolean, expression or function
				//startEvent: 'DOMContentLoaded', // name of the event dispatched on the document, that AOS should initialize on
				//initClassName: 'aos-init', // class applied after initialization
				//animatedClassName: 'aos-animate', // class applied on animation
				//useClassNames: false, // if true, will add content of `data-aos` as classes on scroll
				//disableMutationObserver: false, // disables automatic mutations' detections (advanced)
				//debounceDelay: 50, // the delay on debounce used while resizing window (advanced)
				//throttleDelay: 99, // the delay on throttle used while scrolling the page (advanced)
				
				// Settings that can be overridden on per-element basis, by `data-aos-*` attributes:
				//offset: 120, // offset (in px) from the original trigger point
				//delay: 0, // values from 0 to 3000, with step 50ms
				//duration: 400, // values from 0 to 3000, with step 50ms
				easing: 'ease', // default easing for AOS animations
				once: true, // whether animation should happen only once - while scrolling down
				//mirror: true, // whether elements should animate out while scrolling past them
				anchorPlacement: 'bottom', // defines which position of the element regarding to window should trigger the animation
				});
		</script>
	<style>
.BUTTON_ODC {
   background: #378AC4;
   background-image: -webkit-linear-gradient(top, #378AC4, #1E62D0);
   background-image: -moz-linear-gradient(top, #378AC4, #1E62D0);
   background-image: -ms-linear-gradient(top, #378AC4, #1E62D0);
   background-image: -o-linear-gradient(top, #378AC4, #1E62D0);
   background-image: linear-gradient(to bottom, #378AC4, #1E62D0);
   -webkit-border-radius: 24px;
   -moz-border-radius: 24px;
   border-radius: 24px;
   color: #FFFFFF;
   font-family: Open Sans;
   font-size: 18px;
   font-weight: 100;
   padding: 40px;
   box-shadow-color: ;
   box-shadow-horizontal: 62;
   box-shadow-vertical: 35;
   box-shadow-blur: 47;
   box-shadow-spread: 2;
   text-shadow: 1px 1px 20px #000000;
   border: solid #337FED 0px;
   text-decoration: none;
   display: inline-block;
   cursor: pointer;
   text-align: center;
}

.BUTTON_ODC:hover {
   border: solid #337FED 1px;
   background: #1E62D0;
   background-image: -webkit-linear-gradient(top, #1E62D0, #3D94F6);
   background-image: -moz-linear-gradient(top, #1E62D0, #3D94F6);
   background-image: -ms-linear-gradient(top, #1E62D0, #3D94F6);
   background-image: -o-linear-gradient(top, #1E62D0, #3D94F6);
   background-image: linear-gradient(to bottom, #1E62D0, #3D94F6);
   -webkit-border-radius: 20px;
   -moz-border-radius: 20px;
   border-radius: 20px;
   text-decoration: none;
}
strong{
	color:#378AC4;
}
b{
	color:#378AC4;

}
i{
	color:#378AC4;
}
.zoom {
width: 40px;
height: -30px;
}
.image {
width: 100%;
height: 100%;
}
.image img {
/* La transition s'applique à la fois sur la largeur et la hauteur, avec une durée d'une seconde. */
-webkit-transition: all 2s ease; /* Safari et Chrome */
-moz-transition: all 2s ease; /* Firefox */
-ms-transition: all 2s ease; /* Internet Explorer 9 */
-o-transition: all 2s ease; /* Opera */
transition: all 2s ease;
}
.image:hover img {
/* L'image est grossie de 25% */
-webkit-transform:scale(7.25); /* Safari et Chrome */
-moz-transform:scale(7.25); /* Firefox */
-ms-transform:scale(7.25); /* Internet Explorer 9 */
-o-transform:scale(7.25); /* Opera */
transform:scale(7.25);
}
table, td, th {
  border: 1px solid black;
}

table {
  border-collapse: collapse;
  width: 100%;
   text-align: center;
}

th {
  height: 	100%;
width: 		70px;
}
    </style>

<div id="google_translate_element2"></div>
<script type="text/javascript">
function googleTranslateElementInit2() {new google.translate.TranslateElement({pageLanguage: '',autoDisplay: false}, 'google_translate_element2');}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"></script>
</body>

</html>